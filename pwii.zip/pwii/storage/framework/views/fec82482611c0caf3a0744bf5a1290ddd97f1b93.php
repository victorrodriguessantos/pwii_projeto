<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('style/tabelas.css')); ?>">
    </head>

<body>

<div class="navegation">
    <nav>
        <ul>
        <a href="/"><li>Home</li></a>
        <a href="/listarprodutos"><li>Produtos</li></a>
        <a href="/listarcategoria"><li>Categoria</li></a>
        <a href="/listarcontato"><li>Contato</li></a>
        <a href="/listarfornecedor"><li>Fornecedor</li></a>

        </ul>
    </nav>
</div>

<!-- Inicio Filtro -->
<div class="search">
<form action="<?php echo e(route('contato.index')); ?>" method="GET">
    <input class="box-search"type="text" name="search" placeholder="Pesquisar Contato">
    <input class="btn-search"type="submit" value="Pesquisar">
</form>
</div>
<!-- Fim Filtro -->

<!-- Inicio Formulario -->
<div class="btn-adc">
    <button id="abrir">Adicionar item</button>

    <dialog>
        <h2>Formulario</h2>

        <form action="<?php echo e(route('contato.store')); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Adicione o token CSRF para segurança -->
            <label>Nome</label>
            <input name="name_contato" type="text" placeholder="Nome" required>
            <input name="telefone" type="number" placeholder="Telefone" required>
            <input name="endereco" type="text" placeholder="Endereço" required>

            <input type="submit" value="Cadastrar">
        </form>

        <button id="fechar">Fechar</button>
    </dialog>
</div>
<!-- Fim Formulario -->

<div class="titulo">
    <h1>Contatos</h1>
</div>

<div class="table-container">
    <table>
        <tr>
            <th>ID</th>
            <th>NOME</th>
            <th>TELEFONE</th>
            <th>ENDEREÇO</th>
        </tr>

        <?php $__currentLoopData = $contato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbcontato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($tbcontato -> id_contato); ?> </td>
            <td> <?php echo e($tbcontato -> name_contato); ?> </td>
            <td> <?php echo e($tbcontato -> telefone); ?> </td>
            <td> <?php echo e($tbcontato -> endereco); ?> </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

</div>

<script src="<?php echo e(asset('script/index.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\victo\OneDrive\Área de Trabalho\pwii_projeto\pwii\resources\views/listarcontato.blade.php ENDPATH**/ ?>