<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('style/tabelas.css')); ?>">
    </head>

<body>

<div class="navegation">
    <nav>
        <ul>
        <a href="/"><li>Home</li></a>
        <a href="/listarprodutos"><li>Produtos</li></a>
        <a href="/listarcategoria"><li>Categoria</li></a>
        <a href="/listarcontato"><li>Contato</li></a>
        <a href="/listarfornecedor"><li>Fornecedor</li></a>
        </ul>
    </nav>
</div>

<div class="titulo">
    <h1>Lista de Fornecedores</h1>
</div>

<div class="table-container">
    <table>
        <tr>
            <th>ID</th>
            <th>FORNECEDOR</th>
            <th>CNPJ</th>

        </tr>

        <?php $__currentLoopData = $fornecedor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbfornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($tbfornecedor -> id_fornecedor); ?> </td>
            <td> <?php echo e($tbfornecedor -> name_fornecedor); ?> </td>
            <td> <?php echo e($tbfornecedor -> cnpj); ?> </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

</div>

</body>
</html><?php /**PATH C:\Users\victo\OneDrive\Área de Trabalho\pwii_projeto\pwii\resources\views/listarfornecedor.blade.php ENDPATH**/ ?>