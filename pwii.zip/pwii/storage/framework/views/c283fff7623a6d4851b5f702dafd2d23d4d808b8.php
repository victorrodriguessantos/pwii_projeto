<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('style/tabelas.css')); ?>">
    </head>

<body>

<div class="navegation">
    <nav>
        <ul>
        <a href="/"><li>Home</li></a>
        <a href="/listarprodutos"><li>Produtos</li></a>
        <a href="/listarcategoria"><li>Categoria</li></a>
        <a href="/listarcontato"><li>Contato</li></a>
        <a href="/listarfornecedor"><li>Fornecedor</li></a>
        </ul>
    </nav>
</div>

<!-- Inicio Filtro -->

<div class="search">
<form action="<?php echo e(route('produtos.index')); ?>" method="GET">
    <input class="box-search" type="text" name="search" placeholder="Pesquisar Produto">
    <input class="btn-search"type="submit" value="Pesquisar">
</form>
</div>
<!-- Fim Filtro -->

<div class="btn-adc">
    <button id="abrir">Adicionar item</button>

    <dialog>
        <h2>Formulario</h2>

        <form action="<?php echo e(route('produtos.store')); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Adicione o token CSRF para segurança -->
            <label>Nome</label>
            <input name="txtNome" type="text" placeholder="Nome do produto" required>
            
            <label>Quantidade</label>
            <input name="txtQtd" type="number" placeholder="Quantidade do produto" required>

            <label>Valor</label>
            <input name="txtValor" type="number" step="0.01" placeholder="Valor do produto" required>

            <label>Categoria</label>
                <select name="txtCat" required>
                    <option value="">Selecione uma Categoria</option>
                        <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tbcategoria->id_categoria); ?>"><?php echo e($tbcategoria->name_categoria); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            <input type="submit" value="Cadastrar">
        </form>


        <button id="fechar">Fechar</button>
    </dialog>
</div>


<div class="titulo">
    <h1>Lista de Produtos</h1>
</div>

<div class="table-container">
    <table>
        <tr>
            <th>ID</th>
            <th>PRODUTO</th>
            <th>QUANTIDADE</th>
            <th>VALOR</th>
            <th>CATEGORIA</th>

        </tr>

        <?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbproduto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($tbproduto -> id_produto); ?> </td>
            <td> <?php echo e($tbproduto -> name_produto); ?> </td>
            <td> <?php echo e($tbproduto -> quantidade); ?> </td>
            <td> R$ <?php echo e($tbproduto ->  valor); ?> </td>
            <td><?php echo e($tbproduto->categoria->name_categoria ?? 'Categoria não encontrada'); ?></td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

</div>

<script src="<?php echo e(asset('script/index.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\victo\OneDrive\Área de Trabalho\pwii_projeto\pwii\resources\views/listarprodutos.blade.php ENDPATH**/ ?>